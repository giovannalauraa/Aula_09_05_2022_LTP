public class Main {
    public static void main(String[] args) {

    // Definir a variável do tipo jogador
    Jogador jogador1;

    // Criar um objeto da classe jogador e atribuir para a variável jogador1
    jogador1 = new Jogador();

    // Atribuindo valores para o jogador 1 usando os getters e setters
    jogador1.setPontuacao(100);
    jogador1.setNome("Jeon");
    jogador1.setAtivado(true);


    // Recuperar os valores do jogador 1
    // Usamos os getters

    System.out.println("Nome: " +  jogador1.getNome());
    System.out.println("Pontuação: " + jogador1.getPontuacao()); // Usa o verbo get por isso get
    System.out.println("Está ativado? " + jogador1.isAtivado());  //Usa o verbo to be não o verbo get, por isso "is" 

    
    



    
    

    }
    
    
}
