public class Jogador {
    //Especificar os campos
    //Especificar os métodos

    private double pontuacao; // O privado ajuda a termos controle dos dados
    private String nome;
    private boolean ativado;

    public double getPontuacao() {
        return pontuacao;
    }
    public void setPontuacao(double pontuacao) {
        this.pontuacao = pontuacao;
    }
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public boolean isAtivado() {
        return ativado;
    }
    public void setAtivado(boolean ativado) {
        this.ativado = ativado;
    }
    
}


/*ATIVIDADE 1 (PROFESSOR)
Crie uma classe chamada Jogador. Crie três atributos: pontuacao, do tipo double; nome, do tipo String; ativado, do tipo bool. Na classe principal main declare uma variável do
tipo da classe criada e a instancie com um objeto do tipo. Insira valores em cada um dos campos do objeto e os imprima.*/