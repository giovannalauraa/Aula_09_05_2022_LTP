public class Main {
    public static void main(String[] args) {
        // Definindo o tipo da classe
        Author author2 = new Author();
        Book book2 = new Book();

        //Atribuindo valores para os livros usando os gets e sets
        book2.setName("Nome do livro");
        book2.setAuthor("Nome do autor");
    }
}
